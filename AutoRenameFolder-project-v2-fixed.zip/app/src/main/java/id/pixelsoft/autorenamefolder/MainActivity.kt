package id.pixelsoft.autorenamefolder

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.IOException
import java.nio.file.Files

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var permissionScreenOpened = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Auto Rename Folder"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Memeriksa folder…"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        setContentView(layout)
        prosesRename()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && permissionScreenOpened) {
            permissionScreenOpened = false
            prosesRename()
        }
    }

    private fun prosesRename() {
        if (!Environment.isExternalStorageManager()) {
            status.text = "Aktifkan izin 'Akses semua file' untuk aplikasi ini, lalu kembali ke aplikasi."
            permissionScreenOpened = true
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
            return
        }

        val root = Environment.getExternalStorageDirectory()
        val sumber = File(root, "valtGallery")

        if (!sumber.isDirectory) {
            status.text = "Folder valtGallery tidak ditemukan di root memori internal."
            return
        }

        var tujuan = File(root, "trashbin")
        if (tujuan.exists()) {
            var nomor = 1
            do {
                tujuan = File(root, "trashbin_$nomor")
                nomor++
            } while (tujuan.exists())
        }

        try {
            Files.move(sumber.toPath(), tujuan.toPath())
            status.text = "Berhasil: valtGallery sekarang bernama ${tujuan.name}."
        } catch (e: IOException) {
            status.text = "Rename gagal: ${e.localizedMessage ?: "kendala penyimpanan"}"
        } catch (e: SecurityException) {
            status.text = "Android menolak akses ke folder tersebut."
        } catch (e: UnsupportedOperationException) {
            status.text = "Operasi rename tidak didukung oleh penyimpanan ini."
        }
    }
}
